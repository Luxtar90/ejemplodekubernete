# --- On cloud resources ---
# Datastore configuration
PROJECT_ID = 'cloudtpu-vcn'

# Memorystore configuration
REDIS_HOST = '10.0.0.3'
REDIS_PORT = 6379
# REDIS_PASSWORD = 'password'
