# --- On cloud resources ---
# Mongo configuration
#MONGO_URI = 'connectionString'

# Redis configuration
#REDIS_HOST = 'connectionString'
#REDIS_PORT = port
#REDIS_PASSWORD = 'password'

# --- Localhost resources ---
# # Mongo configuration
import urllib.parse

MONGO_URI = 'mongodb+srv://demo:XuWqtj6mNLqdRGe@cluster0-x6ggd.gcp.mongodb.net/test?retryWrites=true&w=majority'
#
# # Redis configuration
REDIS_HOST = 'redis-15246.c124.us-central1-1.gce.cloud.redislabs.com'
REDIS_PORT = 15246
REDIS_PASSWORD = 'YES6pZxLplJHBnW37GfqJ04yuUAACHjd'